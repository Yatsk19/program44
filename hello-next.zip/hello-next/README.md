# Hello Next.js

Simple Next.js app with App Router that displays "Hello Vitaliy Yashchenko".

## Installation

```bash
npm install
```

## Run development server

```bash
npm run dev
```

Then open [http://localhost:3000](http://localhost:3000) in your browser.

## Screenshot

- ![hello-page](screenshots/hello-page.png)
- ![node-version](screenshots/node-version.png)
