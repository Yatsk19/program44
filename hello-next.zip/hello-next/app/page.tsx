export default function Home() {
  return (
    <main style={{ textAlign: 'center', padding: '100px', fontSize: '2rem' }}>
      Hello Vitaliy Yashchenko
    </main>
  );
}
